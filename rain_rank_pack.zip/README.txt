Rain rank pack

Unicode mapping:
E001 = rain_squad badge
E002 = rain_vip badge
E003 = rain_joueur badge

Suggested LuckPerms prefixes:
/lp group rainsquad meta setprefix 100 " "
/lp group rainvip meta setprefix 100 " "
/lp group rainjoueur meta setprefix 100 " "

Suggested DeluxeChat format:
%luckperms_prefix%%player_name% &7: &f%message%
