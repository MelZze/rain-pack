LuckPerms prefixes:
/lp group rainsquad meta setprefix 100 "\uE001 "
/lp group rainvip meta setprefix 100 "\uE002 "
/lp group rainjoueur meta setprefix 100 "\uE003 "
